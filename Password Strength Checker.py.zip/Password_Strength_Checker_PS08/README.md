# Password Strength Checker — PS No. 8

**University:** Rungta International Skills University  
**School:** School of Information Technology  
**Course:** Bachelor of Computer Application (BCA)  
**Language:** Python 3

## Overview
A console-based program that checks a password against five rules, calculates a score out of five, classifies it as Weak, Medium, or Strong, and suggests improvements.

## Objectives
- Validate password length and character types.
- Use Python strings, conditions, functions, and regular expressions.
- Reject empty input and whitespace.
- Display a score, classification, failed rules, and suggestions.

## Rules and scoring
Each satisfied rule earns one point:
1. At least 8 characters.
2. At least one uppercase letter.
3. At least one lowercase letter.
4. At least one digit.
5. At least one special character from `@#$%&*!`.

| Score | Strength |
|---|---|
| 0–2 | Weak |
| 3–4 | Medium |
| 5 | Strong |

## Requirements
- Python 3.8 or newer recommended.
- No third-party packages; the program uses the built-in `re` module.

## Files
- `one.py` — complete source code.
- `README.md` — documentation.
- `requirements.txt` — dependency information.
- `test_cases.txt` — university test cases.
- `test_results.txt` — execution status.
- `TEST_EVIDENCE.pdf` — test evidence summary.

## Run
Open a terminal in this folder and run:
```bash
python one.py
```
Enter a password when prompted. Enter `exit` to quit.

## Test cases
1. `abc123` → Weak (2/5); suggest 8+ characters, uppercase, and special character.
2. `Hello123` → Medium (4/5); suggest a special character.
3. Empty input → `Password cannot be empty.`
   `Hello 123` → `Password must not contain spaces.`
4. `Hello@123Xy` → Strong (5/5); no suggestions.

## Algorithm
1. Read a password.
2. Reject empty or whitespace-containing input.
3. Check the five rules using conditions and regex.
4. Add one point for each passed rule.
5. Classify the score and collect suggestions for failed rules.
6. Display the report and repeat until `exit`.

## Security note
This is an educational rule checker, not a full password-security audit. It does not check breach databases or estimate guessing resistance. Do not enter a real personal password during a demonstration.
