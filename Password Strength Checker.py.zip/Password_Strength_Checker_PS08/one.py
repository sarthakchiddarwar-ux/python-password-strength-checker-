"""
PASSWORD STRENGTH CHECKER | PS 8 | Python 3
Five rules: 8+ characters, uppercase, lowercase, digit, special character.
Scoring: 0-2 Weak, 3-4 Medium, 5 Strong.
"""
import re  # Import regular expressions for character-pattern checks.

def check_password(password):  # Check all five password rules.
    score = 0  # Initialize the score.
    suggestions = []  # Store tips for improving the password.
    failed_rules = []  # Store rules that the password does not satisfy.

    if len(password) >= 8:  # Check minimum password length.
        score += 1  # Award one point for sufficient length.
    else:  # Handle a short password.
        failed_rules.append("Minimum length (8 characters)")  # Record the failed rule.
        suggestions.append("Use at least 8 characters")  # Suggest a longer password.

    if re.search(r"[A-Z]", password):  # Regex check for uppercase letters.
        score += 1  # Award one point for uppercase.
    else:  # Handle missing uppercase letters.
        failed_rules.append("At least one uppercase letter")  # Record the failed rule.
        suggestions.append("Add an uppercase letter")  # Suggest uppercase.

    if re.search(r"[a-z]", password):  # Regex check for lowercase letters.
        score += 1  # Award one point for lowercase.
    else:  # Handle missing lowercase letters.
        failed_rules.append("At least one lowercase letter")  # Record the failed rule.
        suggestions.append("Add a lowercase letter")  # Suggest lowercase.

    if re.search(r"[0-9]", password):  # Regex check for digits.
        score += 1  # Award one point for a digit.
    else:  # Handle missing digits.
        failed_rules.append("At least one digit")  # Record the failed rule.
        suggestions.append("Add a number (0-9)")  # Suggest a digit.

    if re.search(r"[@#$%&*!]", password):  # Regex check for allowed special characters.
        score += 1  # Award one point for a special character.
    else:  # Handle missing special characters.
        failed_rules.append("At least one special character (@#$%&*!)")  # Record the failed rule.
        suggestions.append("Add a special character from @#$%&*!")  # Suggest a special character.

    if score <= 2:  # Classify scores from zero to two.
        strength = "Weak"  # Set the Weak classification.
    elif score <= 4:  # Classify scores three and four.
        strength = "Medium"  # Set the Medium classification.
    else:  # Handle a score of five.
        strength = "Strong"  # Set the Strong classification.
    return score, strength, failed_rules, suggestions  # Return the complete analysis.

def display_result(password):  # Validate input and show its analysis.
    if password == "":  # Check for empty input.
        print("Password cannot be empty.")  # Show the required error.
        return  # Stop processing this input.
    if re.search(r"\s", password):  # Reject spaces and other whitespace using regex.
        print("Password must not contain spaces.")  # Show the required error.
        return  # Stop processing this input.

    score, strength, failed_rules, suggestions = check_password(password)  # Analyze the password.
    print("\n---------- PASSWORD STRENGTH REPORT ----------")  # Print report heading.
    print(f"Strength: {strength} ({score}/5)")  # Display strength and score.
    if suggestions:  # Check whether improvements are needed.
        print("Suggestions:")  # Print suggestions heading.
        for suggestion in suggestions:  # Loop through each suggestion.
            print(f"- {suggestion}")  # Display the current suggestion.
    else:  # Handle a password that passes all rules.
        print("No suggestions. Your password is secure.")  # Display success message.
    if failed_rules:  # Check whether any rules failed.
        print("Rules not satisfied:")  # Print failed-rules heading.
        for rule in failed_rules:  # Loop through failed rules.
            print(f"- {rule}")  # Display the current failed rule.
    print("-----------------------------------------------")  # Close the report.

def main():  # Main console application.
    print("Welcome to the Password Strength Checker!")  # Display welcome message.
    print("Rules: 8+ characters, uppercase, lowercase, digit, special character.")  # Explain rules.
    print("Allowed special characters: @#$%&*!")  # Show accepted special characters.
    while True:  # Continue until the user exits.
        password = input("\nEnter a password (or type exit to quit): ")  # Read user input.
        if password.lower() == "exit":  # Check exit command.
            print("Thank you for using Password Strength Checker.")  # Display exit message.
            break  # End the loop.
        display_result(password)  # Check and display the entered password.

if __name__ == "__main__":  # Run only when this file is executed directly.
    main()  # Start the application.
